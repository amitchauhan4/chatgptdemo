// import 'package:flutter/material.dart';
// import 'chatgpt.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatService {
  static const String apiKey =
      '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'; // ⚠️ Replace with your key
  static const String apiUrl = 'https://api.openai.com/v1/chat/completions';

  static Future<String> sendMessage(String message) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': 'gpt-3.5-turbo',
        'messages': [
          {'role': 'user', 'content': message},
        ],
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'].toString().trim();
    } else {
      throw Exception('Failed to get response');
    }
  }
}
